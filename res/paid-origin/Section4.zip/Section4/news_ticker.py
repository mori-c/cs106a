import tkinter
import time

CANVAS_HEIGHT = 100
CANVAS_WIDTH = 500

DX = 4
DY = 0
DELAY = 0.01


def main():
    canvas = make_canvas(CANVAS_WIDTH, CANVAS_HEIGHT, "News Ticker")
    pass

    canvas.mainloop()


"""
Youdon't need to modify code below here
"""


def get_right_x(canvas, object):
    bbox = canvas.bbox(object)
    return bbox[2]


def make_canvas(width, height, title):
    """
    Creates and returns a drawing canvas
    of the given int size with a blue border,
    ready for drawing.
    """
    top = tkinter.Tk()
    top.minsize(width=width, height=height)
    top.title(title)
    canvas = tkinter.Canvas(top, width=width + 1, height=height + 1)
    canvas.pack()
    return canvas


if __name__ == "__main__":
    main()
