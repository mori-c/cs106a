"""
File: examplefor.py
------------------
Print the first 100 even numbers
"""
import math

MAX_SPACES = 50


def main():
    for i in range(5):
        forward_back_together()
    forward_back_just_o()
    move_to_middle()
    for i in range(3):
        print_diamond()


def move_to_middle():
    half_way = MAX_SPACES // 2
    for i in range(half_way):
        print_io(i, 0)


def forward_back_just_o():
    for i in range(MAX_SPACES):
        print_io(0, i)
    for i in range(MAX_SPACES, -1, -1):
        print_io(0, i)


def forward_back_together():
    for i in range(MAX_SPACES):
        print_io(i, 0)
    for i in range(MAX_SPACES, -1, -1):
        print_io(i, 0)


def print_diamond():
    half_way = MAX_SPACES // 2
    # split to the edges
    for i in range(half_way):
        print_io(half_way - i, i * 2)
    # come back together
    for i in range(half_way, -1, -1):
        print_io(half_way - i, i * 2)


def print_io(space_1, space_2):
    print_spaces(space_1)
    print_no_return('i')
    print_spaces(space_2)
    print_no_return('o')
    print('')


def print_spaces(n):
    for i in range(n):
        print_no_return(' ')


def print_no_return(to_print):
    print(to_print, end="")


# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()