"""
File: examplefor.py
------------------
Print the first 100 even numbers
"""
import math


def main():

    def max(a, b):
        print('lol')

    print(max(2, 3))
    print(math.sqrt(25))


# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()