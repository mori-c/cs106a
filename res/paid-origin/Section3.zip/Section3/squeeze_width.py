from simpleimage import SimpleImage


SQUEEZE_FACTOR = 3


def squeeze_width(filename, n):
    pass


def main():
    squeeze_width('karel.png', SQUEEZE_FACTOR)


if __name__ == "__main__":
    main()
