from simpleimage import SimpleImage


def double_left(filename):
    """
    Takes the left half of image, and copies it on top of the right half.
    """
    pass


def main():
    double_left('karel.png')


if __name__ == "__main__":
    main()
