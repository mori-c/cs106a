from simpleimage import SimpleImage

PIXELS_TO_CROP = 30


def crop_image(filename, n):
    """
    Takes the left half of image, and copies it on top of the right half.
    """
    pass


def main():
    crop_image('karel.png', PIXELS_TO_CROP)


if __name__ == "__main__":
    main()
