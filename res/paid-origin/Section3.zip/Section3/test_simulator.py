"""
File: test_simulator.py
-----------------------
Write your solution to the Medical Test Simulator
from section 3 here
"""

import random


def simulate_tests(num_people, test_accuracy, infection_rate):
    pass


def main():
    pass


if __name__ == "__main__":
    main()
