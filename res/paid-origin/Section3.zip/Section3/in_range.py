
def in_range(n, low, high):
	"""
	>>> in_range(2, 1, 3)
	True 
	>>> in_range(2, 3, 1)
	False
	>>> in_range(1, 1, 1)
	True
	"""
    pass


def main():
    pass


if __name__ == "__main__":
    main()
