'''
Read all the lines in the file holdup.txt
and print them to the screen
'''

FILE_NAME = 'holdup.txt'

def main():
	pass

if __name__ == '__main__':
	main()