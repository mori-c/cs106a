import random

def main():
    while True:
        input('Press enter for next word:')
        print('')
        print('Karel')

if __name__ == '__main__':
    main()